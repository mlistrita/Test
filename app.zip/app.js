const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const mysql = require('mysql2/promise');

const app = express();

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Set the view engine to EJS
app.set('view engine', 'ejs');

// Database connection settings
const dbConfig = {
    host: process.env.DB_HOST || 'awseb-e-zfwg3evj4k-stack-awsebrdsdatabase-muda2pvk2on7.cpwe2acsyjmt.us-east-1.rds.amazonaws.com', // Replace with your RDS endpoint
    user: process.env.DB_USER || 'mlistrita', // Replace with your database username
    password: process.env.DB_PASSWORD || 'Mydb1234', // Replace with your database password
    database: process.env.DB_NAME || 'wseb-e-zfwg3evj4k-stack-awsebrdsdatabase-muda2pvk2on7.cpwe2acsyjmt.us-east-1.rds.amazonaws.com' // Replace with the correct database name
};

// Test database connection
const testDbConnection = async () => {
    try {
        const connection = await mysql.createConnection(dbConfig);
        console.log('Connected to the database successfully.');
        await connection.end();
    } catch (err) {
        console.error('Database connection failed:', err.message);
    }
};

testDbConnection();

// Routes

// Home Page
app.get('/', (req, res) => {
    res.render('index', { title: 'Welcome to the DatingApp' });
});

// Registration Page
app.get('/auth/register', (req, res) => {
    res.render('register', { title: 'Register for DatingApp' });
});

// Handle Registration Form Submission
app.post('/auth/register', async (req, res) => {
    const { username, email, password } = req.body;

    try {
        const connection = await mysql.createConnection(dbConfig);
        const query = 'INSERT INTO users (username, email, password) VALUES (?, ?, ?)';
        await connection.execute(query, [username, email, password]);
        console.log('User registered successfully.');
        await connection.end();
        res.redirect('/auth/login');
    } catch (err) {
        console.error('Error during registration:', err.message);
        res.status(500).send('Error during registration.');
    }
});

// Login Page
app.get('/auth/login', (req, res) => {
    res.render('login', { title: 'Login to DatingApp' });
});

// Handle Login Form Submission
app.post('/auth/login', async (req, res) => {
    const { email, password } = req.body;

    try {
        const connection = await mysql.createConnection(dbConfig);
        const query = 'SELECT * FROM users WHERE email = ? AND password = ?';
        const [results] = await connection.execute(query, [email, password]);
        await connection.end();

        if (results.length > 0) {
            console.log('User logged in successfully:', results[0]);
            res.redirect('/users/profile');
        } else {
            console.log('Invalid login credentials.');
            res.status(401).send('Invalid email or password.');
        }
    } catch (err) {
        console.error('Error during login:', err.message);
        res.status(500).send('Error during login.');
    }
});

// Profile Page
app.get('/users/profile', (req, res) => {
    // Dummy data (replace with actual session/user data later)
    const user = { username: 'JohnDoe', email: 'john@example.com' };
    res.render('profile', { title: 'Your Profile', user });
});

// Test Route for Debugging Database Connection
app.get('/debug-db', async (req, res) => {
    try {
        const connection = await mysql.createConnection(dbConfig);
        await connection.query('SELECT 1 + 1 AS solution');
        await connection.end();
        res.send('Database connection successful!');
    } catch (err) {
        console.error('Database connection failed:', err.message);
        res.status(500).send('Database connection failed: ' + err.message);
    }
});

// Start the Server
const port = process.env.PORT || 3000;
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});
